# Class 12 CS Python Project
print("Hello! Project loaded successfully.")